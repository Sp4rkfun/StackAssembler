package com.assembler.instructions.io;

import com.assembler.Instruction;

public class Input extends Instruction {

	public Input() {
		super("inp", "1111");
	}

	@Override
	public void runProcedure() {
		// TODO Auto-generated method stub

	}

}
