package com.assembler.instructions.io;

import com.assembler.Instruction;

public class Display extends Instruction {

	public Display() {
		super("disp", "1110000000000000");
	}

	@Override
	public void runProcedure() {
		super.runProcedure();
	}

}

