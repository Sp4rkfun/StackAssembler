package com.assembler.instructions.assertions;


public class Assertion extends com.assembler.Instruction {

	public Assertion(String name, String opcode) {
		super(name, opcode);
	}

}
