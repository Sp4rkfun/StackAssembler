package com.assembler.instructions.pseudo;

import com.assembler.Instruction;

public class JumpRegister extends Instruction {

	public JumpRegister() {
		super("jr", "000000000000000");
		// TODO Auto-generated constructor stub
	}

}
